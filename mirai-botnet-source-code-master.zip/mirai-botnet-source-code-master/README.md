# linux.mirai

Leaked Linux.Mirai Source Code for Research/IoC Development Purposes

Uploaded for research purposes and so we can develop IoC's and such.

See "post.txt" (transcribed in [post.md](post.md)) for the post in which it
leaks, if you want to know how it is all set up and the likes.

Requirements
Bare Minimum
2 servers: 1 for CNC + mysql, 1 for scan receiver, and 1+ for loading

Credits

Anna-senpai

Disclaimer

This repository is for academic purposes, the use of this software is your responsibility.

Warning

The zip file for the is repo is being identified by some AV programs as malware. Please take caution.
